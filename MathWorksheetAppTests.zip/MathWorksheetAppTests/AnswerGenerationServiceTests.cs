﻿using MathWorksheetApp.Models;
using MathWorksheetApp.Services;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MathWorksheetAppTests
{
    [TestClass]
    public class AnswerGenerationServiceTests
    {
        private AnswerGenerationService _answerGenerationService;
        private ConstantProblemGenerationService _problemGenerationService;
        private WorksheetSubmission _worksheet;

        [TestInitialize]
        public void Initialize()
        {
            _problemGenerationService = new ConstantProblemGenerationService();
            _answerGenerationService = new AnswerGenerationService(_problemGenerationService);
            _worksheet = new WorksheetSubmission()
            {
                Operation = OperationSign.ADD,
                ConstantOperand = 3,
                Count = 10,
                Maximum = 10,
                Minimum = 0,
                IncludeAnswers = true,
                ProblemType = ProblemType.CONSTANT
            };
        }

        [TestMethod]
        public void GetDocument_GivenWorksheet_ReturnsNonNullAnswers()
        {
            var actual = _answerGenerationService.GetDocument(_worksheet);

            Assert.AreEqual(10, actual.MathProblems.Count);
            Assert.AreEqual(10, actual.Answers.Count);
            Assert.IsNotNull(actual.Answers);
            foreach(var answer in actual.Answers)
            {
                Assert.IsNotNull(answer);
            }
        }
    }
}
