﻿using MathWorksheetApp.Models;
using MathWorksheetApp.Services;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;

namespace MathWorksheetAppTests
{
    [TestClass]
    public class PdfServiceTests
    {
        private List<MathProblem> _mathProblems;
        private PdfService _pdfService;
        private DocumentAdapter _document;

        [TestInitialize]
        public void Initialize()
        {
            _document = new DocumentAdapter();
            _mathProblems = new List<MathProblem>
            {
                new MathProblem
                {
                    FirstOperand = 1,
                    SecondOperand = 2,
                    Operation = OperationSign.ADD
                },
                new MathProblem
                {
                    FirstOperand = 3,
                    SecondOperand = 4,
                    Operation = OperationSign.SUBTRACT
                },
                new MathProblem
                {
                    FirstOperand = 5,
                    SecondOperand = 6,
                    Operation = OperationSign.MULTIPLY
                }
            };
            _pdfService = new PdfService();
            _document.MathProblems = _mathProblems;
            _document.Answers = null;
        }

        [TestMethod]
        public void CreatePdf_GivenMathProblems_CreatesPdf()
        {
            _pdfService.CreatePdf(_document);
        }

        [TestMethod]
        public void CreatePdf_GivenMoreMathProblems_CreatesPdf()
        {
            var generationService = new RandomProblemGenerationService();
            var worksheet = new WorksheetSubmission()
            {
                Count = 10,
                Minimum = 0,
                Maximum = 20,
                Operation = OperationSign.ADD
            };
            var document = generationService.GetDocument(worksheet);
            _pdfService.CreatePdf(document);
        }
    }
}
