﻿using MathWorksheetApp.Models;
using MathWorksheetApp.Services;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MathWorksheetAppTests
{
    [TestClass]
    public class RandomProblemGenerationServiceTests
    {
        private RandomProblemGenerationService _generationService;
        private WorksheetSubmission _worksheet;

        [TestInitialize]
        public void Initialize()
        {
            _generationService = new RandomProblemGenerationService();
            _worksheet = new WorksheetSubmission();
        }

        [TestMethod]
        public void GetMathProblems_GivenSubtraction_ProvidesListOfSubtractionProblems()
        {
            _worksheet.Count = 10;
            _worksheet.Minimum = 0;
            _worksheet.Maximum = 20;
            _worksheet.Operation = OperationSign.SUBTRACT;
            var actual = _generationService.GetMathProblems(_worksheet);

            foreach(var problem in actual)
            {
                Assert.IsTrue(problem.FirstOperand >= problem.SecondOperand);
            }
        }

        [DataRow(OperationSign.ADD)]
        [DataRow(OperationSign.MULTIPLY)]
        [TestMethod]
        public void GetMathProblems_GivenAddition_ProvidesListOfAdditionProblemsInRange(OperationSign sign)
        {
            _worksheet.Count = 5;
            _worksheet.Minimum = 0;
            _worksheet.Maximum = 20;
            _worksheet.Operation = sign;
            var actual = _generationService.GetMathProblems(_worksheet);

            Assert.AreEqual(5, actual.Count);

            foreach(var problem in actual)
            {
                Assert.AreEqual(sign, problem.Operation);
                Assert.IsTrue(problem.FirstOperand >= 0 && problem.FirstOperand <= 20);
                Assert.IsTrue(problem.SecondOperand >= 0 && problem.SecondOperand <= 20);
            }
        }

        [TestMethod]
        public void GetMathProblems_GivenDivision_ProvidesListOfDivisionProblems()
        {
            _worksheet.Count = 10;
            _worksheet.Minimum = 0;
            _worksheet.Maximum = 10;
            _worksheet.Operation = OperationSign.DIVIDE;
            var actual = _generationService.GetMathProblems(_worksheet);
            
            foreach(var problem in actual)
            {
                Assert.IsTrue(problem.FirstOperand % problem.SecondOperand == 0);
            }
        }
    }
}
