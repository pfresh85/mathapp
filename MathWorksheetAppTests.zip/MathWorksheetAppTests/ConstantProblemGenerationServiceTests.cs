﻿using MathWorksheetApp.Models;
using MathWorksheetApp.Services;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MathWorksheetAppTests
{
    [TestClass]
    public class ConstantProblemGenerationServiceTests
    {
        private ConstantProblemGenerationService _constantProblemGenerationService;
        private WorksheetSubmission _worksheet;

        [TestInitialize]
        public void Initialize()
        {
            _constantProblemGenerationService = new ConstantProblemGenerationService();
            _worksheet = new WorksheetSubmission();
        }

        [TestMethod]
        public void GetMathProblems_GivenSubtraction_ReturnsSubtractionProblems()
        {
            _worksheet.Count = 10;
            _worksheet.Minimum = 0;
            _worksheet.Maximum = 20;
            _worksheet.Operation = OperationSign.SUBTRACT;
            _worksheet.ConstantOperand = 5;
            var actual = _constantProblemGenerationService.GetMathProblems(_worksheet);

            foreach (var problem in actual)
            {
                Assert.IsTrue(problem.FirstOperand >= problem.SecondOperand);
                Assert.IsTrue(problem.SecondOperand == 5);
            }
        }

        [TestMethod]
        public void GetMathProblems_GivenDivision_ProvidesListOfDivisionProblems()
        {
            _worksheet.Count = 10;
            _worksheet.Minimum = 0;
            _worksheet.Maximum = 10;
            _worksheet.Operation = OperationSign.DIVIDE;
            _worksheet.ConstantOperand = 5;
            var actual = _constantProblemGenerationService.GetMathProblems(_worksheet);

            foreach (var problem in actual)
            {
                Assert.IsTrue(problem.FirstOperand % problem.SecondOperand == 0);
                Assert.IsTrue(problem.SecondOperand == 5);
            }
        }

        [DataRow(OperationSign.ADD)]
        [DataRow(OperationSign.MULTIPLY)]
        [TestMethod]
        public void GetMathProblems_GivenAddition_ProvidesListOfAdditionProblemsInRange(OperationSign sign)
        {
            _worksheet.Count = 5;
            _worksheet.Minimum = 0;
            _worksheet.Maximum = 20;
            _worksheet.Operation = sign;
            _worksheet.ConstantOperand = 5;
            var actual = _constantProblemGenerationService.GetMathProblems(_worksheet);

            Assert.AreEqual(5, actual.Count);

            foreach (var problem in actual)
            {
                Assert.AreEqual(sign, problem.Operation);
                Assert.IsTrue(problem.FirstOperand >= 0 && problem.FirstOperand <= 20);
                Assert.IsTrue(problem.SecondOperand >= 0 && problem.SecondOperand <= 20);
                Assert.IsTrue(problem.FirstOperand == 5 || problem.SecondOperand == 5);
            }
        }
    }
}
